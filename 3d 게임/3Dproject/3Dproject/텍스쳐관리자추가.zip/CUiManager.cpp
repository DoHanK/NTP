#include "CUiManager.h"
#include "Mesh.h"
#include "Shader.h"	

CUiManager::CUiManager(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList)
{
	m_pShader = new CUIShader();
	m_pMesh = new CUiRectMesh(pd3dDevice, pd3dCommandList);	 

}

//nomalize data
bool CUiManager::CreateNormalUIRect(float top, float bottom, float left, float right)
{
	// is not invalid 
	if (!(top > bottom && right > left))
		return false;

	UIRect* PRect = new UIRect{ top, bottom, left, right };
	RectList.push_back(PRect);
	
	//success
	return true;

}

//pixel coord
bool CUiManager::CreateUIRect(float top , float bottom , float left , float right)
{
	// is not invalid 
	if (!(top < bottom && right > left))
		return false;


	UIRect* PRect = new UIRect{ CreateNormalizePixel(top, bottom, left, right)};
	RectList.push_back(PRect);

	return false;
}

UIRect CUiManager::CreateNormalizePixel(float top, float bottom, float left, float right)
{
	//y coord
	float NormalTop = 1 - ((top * 2) / FRAME_BUFFER_HEIGHT);
	float NormalBottom = 1 - ((bottom * 2) / FRAME_BUFFER_HEIGHT);
	//x coord
	float NormalLeft = -1+((left * 2) / FRAME_BUFFER_WIDTH);
	float NormalRight = -1+ ((right * 2) / FRAME_BUFFER_WIDTH);




	return { NormalTop, NormalBottom, NormalLeft, NormalRight };
}

void CUiManager::AlDrawRect(ID3D12GraphicsCommandList* pd3d12CommandList)
{
	m_pShader->OnPrepareRender(pd3d12CommandList, 1);

	if (m_pMesh) {
		for (UIRect* e : RectList) {
			m_pMesh->UpdataVertexPosition(*e);
			m_pMesh->Render(pd3d12CommandList);
		}
	}
}

