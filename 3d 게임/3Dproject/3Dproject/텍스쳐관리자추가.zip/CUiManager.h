#pragma once
#include "stdafx.h"
#include "Mesh.h"
#include "Shader.h"
#include "CMeshManager.h"




// this hararchy is equal at Framwork
class CUiManager
{
public:

	list<UIRect*> RectList;

	CUiRectMesh* m_pMesh = NULL;
	CUIShader* m_pShader = NULL;


	//Function
	CUiManager(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList);
	~CUiManager() {};
	bool CreateNormalUIRect(float top, float bottom ,float left, float right);
	bool CreateUIRect(float top, float bottom, float left, float right);
	void AlDrawRect(ID3D12GraphicsCommandList* pd3d12CommandList);
	UIRect CreateNormalizePixel(float top, float bottom, float left, float right);
};

